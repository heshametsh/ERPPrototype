[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$testsScript = Join-Path $PSScriptRoot 'Invoke-ERPTests.ps1'

if (-not (Test-Path -LiteralPath $testsScript)) {
    throw "Could not find the existing ERP test runner: $testsScript"
}

$hadPreviousValue = Test-Path Env:ERP_PERFORMANCE_SOAK
$previousValue = $env:ERP_PERFORMANCE_SOAK

try {
    $env:ERP_PERFORMANCE_SOAK = '1'

    Write-Host 'ERPPrototype Arrow-only performance soak' -ForegroundColor Cyan
    Write-Host 'Protocol: cold Arrow Down -> same-sheet continuation -> long-session Arrow Down'
    Write-Host 'The page is not refreshed between the cold and long measurements.'
    Write-Host 'Expected browser result when healthy: 63/63 PASS.'
    Write-Host ''

    & powershell.exe `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -File $testsScript `
        -Suite Stress `
        -Observe

    if ($LASTEXITCODE -ne 0) {
        throw "The performance soak failed with exit code $LASTEXITCODE."
    }
}
finally {
    if ($hadPreviousValue) {
        $env:ERP_PERFORMANCE_SOAK = $previousValue
    }
    else {
        Remove-Item Env:ERP_PERFORMANCE_SOAK -ErrorAction SilentlyContinue
    }
}
