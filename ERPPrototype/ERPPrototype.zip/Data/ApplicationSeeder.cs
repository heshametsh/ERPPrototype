﻿using ERPPrototype.Data.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ERPPrototype.Data;

public static class ApplicationSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        await EnsureRolesAsync(services);
        await EnsureInitialAdminAsync(services);
        await EnsureStandardDepartmentStructureAsync(services);
    }

    private static async Task EnsureRolesAsync(IServiceProvider services)
    {
        var roleManager =
            services.GetRequiredService<RoleManager<IdentityRole>>();

        foreach (var roleName in AppRoles.All)
        {
            if (await roleManager.RoleExistsAsync(roleName))
            {
                continue;
            }

            var result =
                await roleManager.CreateAsync(new IdentityRole(roleName));

            ThrowIfIdentityOperationFailed(
                result,
                $"Failed to create role '{roleName}'");
        }
    }

    private static async Task EnsureInitialAdminAsync(
        IServiceProvider services)
    {
        var userManager =
            services.GetRequiredService<UserManager<ApplicationUser>>();

        var configuration =
            services.GetRequiredService<IConfiguration>();

        var existingAdmins =
            await userManager.GetUsersInRoleAsync(AppRoles.Admin);

        if (existingAdmins.Count > 1)
        {
            throw new InvalidOperationException(
                "More than one Admin account exists. " +
                "The current product rules allow exactly one Admin account.");
        }

        var configuredEmail =
            configuration["InitialAdmin:Email"]?.Trim();

        ApplicationUser? initialAdmin =
            existingAdmins.SingleOrDefault();

        if (initialAdmin is not null)
        {
            if (
                !string.IsNullOrWhiteSpace(configuredEmail) &&
                !string.Equals(
                    initialAdmin.Email,
                    configuredEmail,
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "The configured InitialAdmin email does not match " +
                    "the existing Admin account. Remove the obsolete " +
                    "configuration or correct it before startup.");
            }
        }
        else
        {
            var initialAdminPassword =
                configuration["InitialAdmin:Password"];

            var initialAdminFullName =
                configuration["InitialAdmin:FullName"]?.Trim();

            if (string.IsNullOrWhiteSpace(configuredEmail))
            {
                throw new InvalidOperationException(
                    "The initial Admin account does not exist, and " +
                    "'InitialAdmin:Email' was not configured.");
            }

            if (string.IsNullOrWhiteSpace(initialAdminPassword))
            {
                throw new InvalidOperationException(
                    "The initial Admin account does not exist, and " +
                    "'InitialAdmin:Password' was not configured.");
            }

            var conflictingUser =
                await userManager.FindByEmailAsync(configuredEmail);

            if (conflictingUser is not null)
            {
                throw new InvalidOperationException(
                    "InitialAdmin:Email belongs to an existing non-Admin " +
                    "account. The application will not promote that account " +
                    "automatically.");
            }

            initialAdmin = new ApplicationUser
            {
                UserName = configuredEmail,
                Email = configuredEmail,
                EmailConfirmed = true,
                FullName = string.IsNullOrWhiteSpace(initialAdminFullName)
                    ? "Initial Administrator"
                    : initialAdminFullName,
                IsActive = true,
                MustChangePassword = true
            };

            var createResult =
                await userManager.CreateAsync(
                    initialAdmin,
                    initialAdminPassword);

            ThrowIfIdentityOperationFailed(
                createResult,
                $"Failed to create the initial Admin account '{configuredEmail}'");

            var addRoleResult =
                await userManager.AddToRoleAsync(
                    initialAdmin,
                    AppRoles.Admin);

            if (!addRoleResult.Succeeded)
            {
                await userManager.DeleteAsync(initialAdmin);

                ThrowIfIdentityOperationFailed(
                    addRoleResult,
                    "Failed to assign the Admin role to the initial Admin");
            }
        }

        if (!initialAdmin.IsActive)
        {
            initialAdmin.IsActive = true;

            var activateResult =
                await userManager.UpdateAsync(initialAdmin);

            ThrowIfIdentityOperationFailed(
                activateResult,
                "Failed to activate the initial Admin account");
        }

        var currentRoles =
            await userManager.GetRolesAsync(initialAdmin);

        var unexpectedRoles = currentRoles
            .Where(roleName => roleName != AppRoles.Admin)
            .ToList();

        if (unexpectedRoles.Count > 0)
        {
            throw new InvalidOperationException(
                "The single Admin account has unexpected additional roles: " +
                string.Join(", ", unexpectedRoles));
        }

        if (!currentRoles.Contains(AppRoles.Admin))
        {
            var addResult =
                await userManager.AddToRoleAsync(
                    initialAdmin,
                    AppRoles.Admin);

            ThrowIfIdentityOperationFailed(
                addResult,
                "Failed to assign the Admin role to the initial Admin");
        }
    }

    private static async Task EnsureStandardDepartmentStructureAsync(
        IServiceProvider services)
    {
        var dbContext =
            services.GetRequiredService<ApplicationDbContext>();

        var departmentTypes =
            await dbContext.DepartmentTypes.ToListAsync();

        var unexpectedDepartmentTypes = departmentTypes
            .Where(departmentType =>
                !StandardDepartmentTypes.All.Contains(departmentType.Name))
            .Select(departmentType => departmentType.Name)
            .ToList();

        if (unexpectedDepartmentTypes.Count > 0)
        {
            throw new InvalidOperationException(
                "Unexpected department types were found: " +
                string.Join(", ", unexpectedDepartmentTypes));
        }

        foreach (var departmentTypeName in StandardDepartmentTypes.All)
        {
            if (departmentTypes.Any(departmentType =>
                    departmentType.Name == departmentTypeName))
            {
                continue;
            }

            var departmentType = new DepartmentType
            {
                Name = departmentTypeName
            };

            dbContext.DepartmentTypes.Add(departmentType);
            departmentTypes.Add(departmentType);
        }

        await dbContext.SaveChangesAsync();

        var branches = await dbContext.Branches
            .Include(branch => branch.Departments)
            .ToListAsync();

        foreach (var branch in branches)
        {
            var existingDepartmentTypeIds = branch.Departments
                .Select(department => department.DepartmentTypeId)
                .ToHashSet();

            foreach (var departmentType in departmentTypes)
            {
                if (existingDepartmentTypeIds.Contains(departmentType.Id))
                {
                    continue;
                }

                branch.Departments.Add(new Department
                {
                    DepartmentTypeId = departmentType.Id
                });
            }
        }

        await dbContext.SaveChangesAsync();
    }

    private static void ThrowIfIdentityOperationFailed(
        IdentityResult result,
        string operation)
    {
        if (result.Succeeded)
        {
            return;
        }

        var errors = string.Join(
            "; ",
            result.Errors.Select(error => error.Description));

        throw new InvalidOperationException($"{operation}: {errors}");
    }
}
