# START HERE — ERP Prototype (Current Stable Checkpoint)

**الحالة:** مرجع البدء الحالي  
**آخر تحديث:** 2026-07-31  
**الأساس الهندسي:** Step 16E6C  
**نقطة الكود المستقرة الحالية:** Phase 8.6-R1 Stable؛ Phase 8.6-R2 قيد الاختبار  
**جاهزية الإنتاج:** غير جاهز لعميل حقيقي حتى اجتياز اختبارات الأمان والأداء والنشر والتجربة داخل شبكة الشركة

## اقرأ بالترتيب

1. `Documentation/00_DOCUMENTATION_INDEX.md`
2. `Documentation/01_PROJECT_CONTEXT.md`
3. `Documentation/03_CURRENT_IMPLEMENTATION.md`
4. `Documentation/05_WORK_ORDERS_GRID_BEHAVIOUR.md`
5. `Documentation/06_REGRESSION_TEST_CHECKLIST.md`
6. `Documentation/07_KNOWN_ISSUES_AND_TECHNICAL_DEBT.md`
7. `Documentation/09_REFACTOR_ROADMAP.md`
8. `Documentation/14_CHANGE_SUMMARY_2026-07-29_PHASE6_CLOSURE.md`

## ما هو المشروع؟

نظام ويب لمتابعة عمليات شركات المقاولات التي تعمل مع الشركة السعودية للكهرباء أو جهات مشابهة.
النظام لا يستبدل SAP أو UDS؛ الموظف ينفذ العمل الرسمي هناك، ثم يحدث بيانات المتابعة داخل نظامنا حتى تستطيع الشركة متابعة أوامر العمل والتأخير والإنتاجية والمراحل المالية من مكان واحد بدل ملفات Excel المتفرقة.

## التقنية الموجودة فعليًا

- Blazor Web App بنمط Interactive Server
- ASP.NET Core Identity
- Entity Framework Core
- SQL Server محليًا وAzure SQL عند النشر
- Azure App Service
- Tabulator 6.5.0 لشيت أوامر العمل
- Modular Monolith تدريجي داخل مشروع واحد قابل للنشر

لا توجد Syncfusion في التنفيذ الحالي لشيت أوامر العمل.
وثائق Power Apps/Dataverse القديمة مؤرشفة ولا تمثل الاتجاه الحالي.

## القرار التشغيلي للعملاء

في الإصدارات التجارية الأولى:

- كل شركة عميلة لها نسخة تطبيق مستقلة.
- كل شركة لها قاعدة بيانات مستقلة.
- الإعدادات والمستخدمون والأسرار والنسخ الاحتياطية مستقلة.
- نفس مصدر الكود يستخدم لكل العملاء.
- لا نبني Shared-Database Multi-Tenancy الآن.
- لا نستخدم Microservices أو ABP Framework في البروتوتايب الحالي.

## أهم أولوية

شاشة أوامر العمل يجب أن تكون قريبة جدًا من Excel:

- تعديل مباشر داخل الخلية.
- تنقل بالكيبورد.
- تحديد نطاقات خلايا.
- Copy/Paste مع Excel.
- إدراج وحذف صفوف.
- مسح محتوى الخلايا بزر Delete/Backspace بدون حذف الصفوف.
- Undo/Redo داخل الجلسة.
- بحث وفلاتر.
- أداء مقبول مع آلاف الصفوف.

## ما الذي يعمل حاليًا؟

- تسجيل الدخول بدون تسجيل عام.
- Admin واحد.
- أسماء الأدوار التقنية الحالية: `Admin` و`ProjectManager` و`BranchManager` و`Employee`. اسم العرض الوظيفي لـ`Employee` هو **Department Employee / موظف القسم**، ولا نعيد تسمية الـRole التقني الآن.
- إنشاء فروع وأقسامها الأربعة الثابتة.
- شيت أوامر العمل لموظف القسم داخل نطاقه فقط.
- سنوات عمل منفصلة.
- تعديل، بحث، فلاتر، نسخ ولصق، إدراج وحذف صفوف، Undo/Redo وحفظ Delta.
- فحص كل حالات التكرار العالمية للزوج `WorkOrderNumber + WorkTypeCode` عبر السنوات والأقسام، وإظهارها مرتبة حسب صف الشيت.
- RowVersion لاكتشاف تعارض التعديل بين جلستين.
- حفظ هوية الصفوف الجديدة في مكانها بعد الحفظ بدل حذفها وإعادة إدراجها.
- مسح كامل نطاق الخلايا المحدد، حتى عندما يمتد عبر صفوف خرجت من الجزء الظاهر بسبب Virtual DOM.
- رسائل التحقق تبدأ من أول صف متأثر وتتحرك بالترتيب.
- Auto-scroll أثناء سحب تحديد الخلايا عند حافتي الشيت، ويعمل عند بدء التحديد من الصف الأول أو من منتصف الشيت.

## نقطة الاستقرار الحالية — M5D4R3

النقطة الحالية مبنية على:

- E6C كأساس سلوك التنقل والـVirtual DOM وتثبيت موضع الشيت.
- M1 إلى M4 لفصل التشخيص ودورة الحياة والتتبع الهيكلي والإدراج والحذف التدريجي.
- M5A وM5B لتوحيد ملكية Copy/Paste.
- M5C2 لحفظ هوية الصفوف الجديدة في مكانها.
- M5C3 لاكتشاف كل التكرارات عبر السنوات والأقسام.
- M5D2 لمسح النطاق المنطقي الكامل بزر Delete/Backspace.
- M5D3 لترتيب التحقق من أول صف متأثر.
- M5D4R1 لإصلاح Auto-scroll عند بدء التحديد من الصف الأول.
- ضبط السرعة النهائي في `tabulatorRangeAutoScroll.js`:

```javascript
const minimumStep = 8;
const maximumStep = 32;
```

تم اختبار السلوك يدويًا واعتماده بواسطة المستخدم.

## ما الذي لا يعمل كمنتج كامل بعد؟

- شاشة تشغيل Branch Manager غير مكتملة.
- ProjectManager ما زال محدود الوظائف.
- إدارة أسماء المستخدمين وإعادة تعيين كلمات المرور غير مكتملة بالكامل.
- Excel Import/Export غير منفذين.
- Dashboard غير منفذ.
- Warehouse والفواتير غير منفذين.
- لا توجد Automated Tests كافية.
- القياسات أثبتت تدهورًا تدريجيًا في التنقل بعد ضغط مستمر طويل، لكن المستخدم أكد أن السرعة العملية الحالية للأسهم وEnter والـWheel مقبولة؛ لذلك لا يوجد Performance Patch حاليًا، ويعاد فتح الموضوع عند اختبار 10,000 صف أو ظهور شكوى استخدام فعلية.
- أداء حذف صفوف محفوظة أثناء مصالحة الحفظ يحتاج تحسينًا منفصلًا لاحقًا.
- اختبار 10,000 صف، شبكة الشركة، Azure، وإعادة الاتصال ما زال مطلوبًا.

## قاعدة تسليم تعديلات الكود

- التعديل البسيط والواضح ومنخفض المخاطر في ملف واحد، مثل تغيير قيمة أو سطر أو سطرين، يقدم كتعليمات مباشرة: اسم الملف، مكان التعديل، والنص البديل.
- لا يتم إنشاء ZIP لتعديل تافه إلا إذا كان مكانه ملتبسًا أو تأثيره حساسًا.
- التعديل الكبير أو الحساس أو متعدد الملفات يقدم كـ ZIP Patch تراكمي يحتوي فقط على الملفات المطلوب استبدالها.
- لا يتم إرسال نسخة TXT مكررة مع الـZIP.
- لا يوضع `ERPPrototype.csproj.user` أو أي ملف `*.user` داخل ZIP Patch أو حزمة تسليم مستقبلية؛ هذه إعدادات محلية للجهاز فقط.
- يجب تحديد هل يكفي `Save + Ctrl+F5` أم يلزم `Clean/Rebuild`.

**مثال:** تغيير سرعة Auto-scroll من قيمتين في ملف واحد تعديل يدوي. إنشاء موديول Auto-scroll وربطه بدورة حياة الشيت تعديل ZIP متعدد الملفات.

## طريقة العمل بعد كل خطوة

يجب شرح:

1. ماذا تم؟
2. لماذا؟
3. مثال بسيط.
4. ماذا نختبر الآن؟
5. ماذا تبقى؟

## حالة المراحل

- Phase 0 — Engineering foundation: مكتملة.
- Phase 1 — Diagnostics separation: مكتملة.
- Phase 2 — Lifecycle and state separation: مكتملة.
- Phase 3 — Scoped validation and tracking: مكتملة.
- Phase 4 — Incremental structural operations: مكتملة.
- Phase 5 — Clipboard, save reconciliation, duplicates, range clear, and drag auto-scroll: مكتملة وظيفيًا.
- Phase 6.0 — Baseline للجلسة الطويلة: مكتملة؛ أثبتت القياسات أن الأسهم وحدها تنتج تدهورًا تدريجيًا، دون دليل حالي على Memory Leak مباشر.
- Phase 6.1 — Lifecycle/Resource Audit: مكتملة؛ لم يظهر تراكم مستمر في الـTimers أو Observers أو المالكين المعروفين.
- Phase 6.2/6.3 — عزل وإصلاح التنقل: مؤجلان بقرار المنتج لأن الأداء العملي الحالي مقبول، ولا نضيف Patch بلا مشكلة مؤثرة.
- Phase 6.4 — Search Debounce: مؤجل؛ البحث الحالي سريع ولم تظهر شكوى أو قياس يبرر إضافة Timer ومنطق جديد.
- Phase 6.5 — التوثيق والإغلاق: مكتملة.
- Phase 8.1 إلى Phase 8.5-R2 — فصل الصفحة والتحقق والـClipboard/History والصفوف وتتبع الحقول والحفظ: مكتملة ومختبرة.
- Phase 8.6-R1 — مالك واحد لدورة حياة الشيت: مكتملة ومختبرة بعد تغيير السنوات والعودة والـResize والتفاعل.
- Phase 8.6-R2 — مالك واحد لربط تفاعلات الشيت: مكتملة ومختبرة.
- Phase 8.7-R1 — مالك واحد لرحلة الحفظ في Blazor: مكتملة ومختبرة.
- Phase 8.7-R2 — فصل تجهيز طلب الحفظ عن تفسير النتيجة: مكتملة ومختبرة.
- Phase 8.7-R3 — مالك واحد لحالة Dirty ومصالحة Undo/Redo والحفظ: مكتملة ومختبرة؛ ثلاث فتحات متكررة لـ4,949 صفًا كانت 244ms و208ms و232ms.
- Phase 8.8-R1 — فصل تنفيذ استعلامات القراءة في `WorkOrderQueryService`: مكتملة ومختبرة عبر سنوات 5 و2,998 و4,091 و4,949 صفًا.
- Phase 8.8-R2A — شبكة اختبارات Integration لمسار الحفظ: مطبقة وتنتظر تشغيل 6 اختبارات SQL Server.

## الخطوة الهندسية التالية

تشغيل Phase 8.8-R2A من القسم W في `Documentation/06_REGRESSION_TEST_CHECKLIST.md`.

المطلوب بمنطق النظام: قبل نقل أي جزء آخر من `WorkOrderService`، يجب إثبات أن السيرفر يمنع التعديل خارج القسم والتكرار العالمي وRowVersion القديم، وينقل السنة، ويحفظ Add/Update/Delete معًا، ويرجع العملية كلها عند فشل قاعدة البيانات.

لا نضيف إصلاحات كبيرة قبل:

1. تثبيت نقطة Git الحالية.
2. تشغيل Regression Checklist الخاص بالمرحلة.
3. قياس المشكلة قبل تعديلها.
4. إبقاء كل مسؤولية جديدة في ملف مستقل عندما يكون ذلك عمليًا.


## Latest Refactor Step — Phase 8.7-R1

The verified Blazor Save journey now has one file owner: `Components/Pages/WorkOrders.Save.cs`. Nothing in the employee workflow is intentionally different.

Practical example: after pasting Notes into many orders, the same code still validates the sheet, sends only the changed fields, saves them, updates internal row versions, and shows the Arabic result. That complete journey is now separated from opening the page and changing years.

Apply the patch over `Phase8.6-R2-Stable`, build, then run section S of `Documentation/06_REGRESSION_TEST_CHECKLIST.md`. Do not tag the step until runtime testing passes.

## Latest Refactor Step — Phase 8.7-R2

The Save button still follows one journey, but the internal decisions now have clear owners:

- `WorkOrders.SaveRequest.cs` answers: what rows and fields will be sent?
- `WorkOrders.SaveResult.cs` answers: what did the server decide, what rows reconcile, and what message appears?
- `WorkOrders.Save.cs` coordinates the order and browser calls.

Practical example: when a new work order is saved, Request classifies it as Added. Result maps its temporary negative Id to the database Id and leaves one visible row.

Apply the patch over `Phase8.7-R1-Stable`, build, then run section T. Do not tag the step until runtime testing passes.



## Latest Refactor Step — Phase 8.8-R1

`WorkOrderQueryService` now owns the read-only journey for employee scope, available years, and selected-year work-order rows. The page still calls `WorkOrderService.LoadSheetAsync`; that method delegates to Query Service so the UI contract is unchanged.

Practical example: changing from 2026 to 2025 executes only read queries in Query Service. Editing and saving a 2025 order still enters the existing WorkOrderService transaction.

Phase 8.8-R1 runtime regression passed. The next required gate is the section W integration suite.


## Latest Safety Step — Phase 8.8-R2A

`ERPPrototype.IntegrationTests` creates an isolated temporary LocalDB database and calls the real save service directly. It is not compiled into the web application and does not touch the application database.

Run section W. Do not start Phase 8.8-R2 until the final line reports `6/6 passed`.
